# 智训引擎工业模型自进化

本项目从官方工业模型父检查点续训，使用分布漂移诊断和历史实验上下文，请大模型从受限策略中选择训练参数。候选在本轮公开验证集上严格优于父模型才采纳，否则提交父权重副本。公开验证集的选择规则不能保证隐藏测试成绩不下降。

## 当前验证结果

修复版镜像 `team/harness:v2` 已完成构建。官方 SDK Host 替身在无网络、根文件系统只读、2 CPU 和 4 GiB 内存限制下，对 A/B/C 各完成一轮训练协议检查，并对实际上传的检查点各验证 3 条预测。Host 返回预设模型回复，这些结果属于离线 Mock，不证明真实 PyTRiO 调用成功。

- TAR 文件：`dist/harness_v2.tar`，27,660,288 字节，单个 Linux/amd64 镜像。
- SHA-256：`f7964d69aa59c9c655e7821249c17eb30ebe2827a18cd512b3f088e1fa27795a`。
- 策略参数边界检查：131 个用例通过。
- 构建及容器记录：`evidence/image_v2_verification.json` 和 `evidence/image_v2_checks/`。
- 真实模型调用、Token 成本和比赛评测结果仍待平台验证。

## 目录

| 路径 | 内容 |
| --- | --- |
| `submission/app/` | Harness 选手模块、漂移与策略逻辑、官方 NumPy 基线 |
| `submission/Dockerfile` | 多阶段构建，最终环境为 Alpine 3.22 |
| `submission/vendor/` | NumPy 1.26.4 的 CPython 3.12 musllinux 离线 wheel |
| `submission/contest-harness-sdk-1.0.4.tar.gz` | 主办方提供的 SDK，含入口模板 |
| `sdk/contest-harness-sdk-1.0.4/` | 供复现脚本使用的官方 SDK 和 Host 测试替身 |
| `work/e2e.py` | A/B/C 容器训练协议、上传字节摘要及预测检查 |
| `work/sweep.py` | 48 组公开集网格实验复现脚本 |
| `evidence/grid/` | 历史网格汇总、训练报告与逐轮记录 |
| `work/selftest_log.txt` | 历史 A/B/C 各 3 轮 Mock 闭环日志 |
| `submission/NOTICE.md` | 第三方组件、来源与许可说明 |

不包含隐藏测试集、平台密钥、账号密码或官方数据包中的大体积数据。请从比赛平台取得官方公开数据包，解压后应存在 `A/public/train.jsonl`、`A/public/validation.jsonl`、`A/checkpoint.npz`，B/C 同理。

## 构建与离线验证

需要 Docker Desktop 的 Linux 引擎，以及本机已缓存的 `python:3.12-alpine` 和 `alpine:3.22` 基础镜像。数值依赖和 SDK 已随源码提供。不要在镜像中填写 API Key。

在项目根目录设置公开数据位置，然后运行：

```powershell
$env:CONTEST_DATA_ROOT="官方A/B/C数据所在目录"
python work/build_and_check.py
```

也可以手动构建：

```powershell
docker build --pull=false --network=none --platform linux/amd64 --provenance=false --sbom=false -t team/harness:v2 submission
docker run --rm --network none --read-only --tmpfs /tmp:rw,size=64m team/harness:v2 describe
$env:E2E_TARGET="docker"
$env:E2E_IMAGE="team/harness:v2"
$env:E2E_REPORT_DIR="evidence/image_v2_checks"
python work/e2e.py A B C
docker save -o dist/harness_v2.tar team/harness:v2
python submission/tools/verify_image.py dist/harness_v2.tar
```

宿主机的协议检查脚本只依赖 Python 标准库，训练与预测都在容器内运行，不需要在 Windows 安装 NumPy。`local/run_local.py` 和 `work/sweep.py` 属于另一组本机实验脚本，使用前需要在自己的 Python 环境安装匹配的 NumPy。

## 协议与路径

入口为 `python3 /app/harness.py`，支持 `describe`、`train`、`predict`。`CONTEST_SUBMISSION` 必须为模块名 `contest_submission`，不能填写 `/app/contest_submission.py` 或其他文件路径。SDK 的 `template/` 不在 wheel 中，Dockerfile 从 SDK 源码压缩包复制入口模板。

训练 stdin/stdout 为 SDK JSONL 协议，日志只写 stderr。预测每行输入 `{"task":...,"inputs":...}`，SDK 每行输出 `{"outputs":...}`。分类的内层结果为唯一标签与有限分数列表，并且只有一个最高分；回归内层为 `{"value":非负有限数}`，B 的单位为分钟，C 为循环。

平台只读挂载 `/app`、`/data`、`/previous`、`/state`、`/model`，工作输出使用 `/workspace` 和 `/tmp`。大模型通过官方 Host 网关 RPC 访问，容器无需直接联网。基础模型配置为平台选项 `Qwen/Qwen3.8-27B`，有效 PyTRiO Key 仅在比赛表单填写。

## 记录与结果边界

公开实验链接：https://swanlab.cn/@HAAKning/industrial-rsi

该项目含 48 组独立公开集网格实验和 3 组历史 Mock 闭环，共 51 条实验。已核验未登录用户可查看项目及实验详情。新一轮 v2 容器的 3 组 Mock 验证保存在本地 evidence 中，尚未追加至云端项目。

历史网格中的最佳公开验证结果为：A Macro-F1 0.7140297 至 0.7263663，B RMSE 681.1598 至 637.4859 分钟，C RMSE 52.8686 至 51.7370 循环。各组独立从官方父检查点开始，不能把网格最佳结果当作真实大模型闭环或平台正式成绩。

`work/prepare_evidence.py` 用于历史记录校验与导入。已存在上传回执时不要重跑在线导入，以免重复实验。API Key 不应提交到源码、镜像、文档或聊天中。
