"""Build an explicit import plan from historical public-data experiments.

Default is a local dry run. --online requires SwanLab login on this device.
No fake token counts or platform model-call receipts are generated.
"""
import argparse
import ast
import csv
import hashlib
import json
import getpass
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records():
    sweep = ROOT / 'evidence/grid/sweep.csv'
    rows = list(csv.DictReader(sweep.open(encoding='utf-8-sig', newline='')))
    assert len(rows) == 48
    seen = set()
    runs = []
    for r in rows:
        key, epochs, lr = r['dataset'], int(r['epochs']), float(r['lr'])
        identity = (key, epochs, lr)
        assert identity not in seen
        seen.add(identity)
        metric = 'macro_f1' if key == 'A' else 'rmse'
        unit = 'dimensionless' if key == 'A' else ('minute' if key == 'B' else 'cycle')
        directory = ROOT / f'evidence/grid/{key}/e{epochs}-lr{lr}'
        training = json.loads((directory / 'training.json').read_text(encoding='utf-8-sig'))
        assert abs(float(r['before']) - training['validation_before'][metric]) < 1e-9
        assert abs(float(r['after']) - training['validation_after'][metric]) < 1e-9
        before, after = float(r['before']), float(r['after'])
        history_path = directory / 'history.jsonl'
        history = [json.loads(line) for line in history_path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
        assert len(history) == epochs, (identity, len(history))
        assert abs(float(history[-1]['validation'][metric]) - after) < 1e-9
        steps = [dict(step=0, metrics=dict(training['validation_before']))]
        for number, epoch in enumerate(history, 1):
            values = dict(epoch['validation'])
            values.update(loss=float(epoch['loss']), epoch=int(epoch['epoch']), optimizer_step=int(epoch['step']))
            steps.append(dict(step=number, metrics=values))
        summary = dict(training['validation_after'])
        summary.update(delta=after-before,
                       improved=int(after>before if key=='A' else after<before),
                       wall_seconds=float(r['wall_seconds']),
                       training_seconds=float(r['training_seconds']))
        steps.append(dict(step=epochs+1, metrics=summary))
        runs.append(dict(
            name=f'grid-{key}-e{epochs}-lr{lr}', group='historical-grid',
            config=dict(dataset=key, epochs=epochs, lr=lr, seed=training['seed'],
                        metric=metric, unit=unit, evidence_type='historical_import',
                        model_access='none', original_created_at=training.get('created_at'),
                        numpy_version=training.get('numpy_version'),
                        python_version=training.get('python_version'),
                        train_sha256=training.get('train_sha256'),
                        validation_sha256=training.get('validation_sha256'),
                        parent_checkpoint_sha256=training.get('parent_checkpoint_sha256'),
                        source_sha256=training.get('source_sha256'),
                        training_report_sha256=sha(directory / 'training.json'),
                        history_sha256=sha(history_path), original_training_report=training,
                        original_epoch_history=history),
            steps=steps))
    raw = (ROOT / 'work/selftest_log.txt').read_bytes()
    text = raw.decode('utf-16') if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else raw.decode('utf-8-sig')
    current = None
    traces = {k:[] for k in 'ABC'}
    pattern = r"第(\d+)轮.*epochs=(\d+) lr=([0-9.]+).*指标=(\{.*\}) 采纳=(True|False)"
    baseline = {k:next(x['steps'][0]['metrics'] for x in runs if x['config']['dataset']==k) for k in 'ABC'}
    selected = {k:dict(v) for k,v in baseline.items()}
    for line in text.splitlines():
        match = re.search(r'数据集 ([ABC])', line)
        if match:
            current = match.group(1)
        match = re.search(pattern, line)
        if not match:
            continue
        assert current
        round_no, epochs, lr, payload, adopted = match.groups()
        values = ast.literal_eval(payload)
        metric = 'macro_f1' if current == 'A' else 'rmse'
        candidate = float(values[metric]); parent = selected[current][metric]
        adopted = adopted == 'True'
        assert adopted == (candidate>parent if current=='A' else candidate<parent)
        if adopted:
            selected[current][metric] = candidate
        traces[current].append(dict(step=int(round_no),metrics={
            'parent_'+metric:parent, 'candidate_'+metric:candidate,
            'selected_'+metric:selected[current][metric], 'adopted':int(adopted),
            'epochs':int(epochs), 'lr':float(lr)}))
    for key, steps in traces.items():
        assert len(steps) == 3, (key, steps)
        runs.append(dict(name=f'mock-loop-{key}',group='historical-mock',
                         config=dict(dataset=key,evidence_type='historical_import',
                                     model_access='mock', rounds=3,
                                     source_log_sha256=sha(ROOT/'work/selftest_log.txt'),
                                     source_log_text=text,
                                     limitation='Not a real PyTRiO call or official evaluation'),
                         steps=steps))
    return runs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--online',action='store_true')
    parser.add_argument('--project',default='industrial-rsi')
    parser.add_argument('--workspace')
    parser.add_argument('--prompt-key', action='store_true', help='Read SwanLab API Key privately, without saving it')
    args = parser.parse_args()
    runs = records()
    destination = ROOT / 'evidence/swanlab_import_plan.json'
    destination.write_text(json.dumps(runs,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Validated {len(runs)} runs: 48 historical grid trials + 3 mock loops.')
    if not args.online:
        print('DRY RUN only. No data uploaded. Model usage/token counts remain unmeasured.')
        return
    import swanlab
    receipt_path = ROOT / 'evidence/swanlab_upload_receipts.json'
    if receipt_path.exists():
        raise RuntimeError('Upload receipts already exist. Inspect the project before another upload.')
    if args.prompt_key:
        secret = getpass.getpass('Paste SwanLab API Key (hidden input; NOT the PyTRiO key): ')
        if not secret.strip():
            raise RuntimeError('SwanLab API Key was empty. Nothing uploaded.')
        try:
            swanlab.login(api_key=secret.strip(), save=False)
        except Exception:
            raise RuntimeError('SwanLab login failed. Check the key and network locally.') from None
        finally:
            del secret
    journal = dict(project=args.project, workspace=args.workspace,
                   swanlab_version=getattr(swanlab, '__version__', 'unknown'),
                   state='in_progress', runs=[])
    def checkpoint():
        receipt_path.write_text(json.dumps(journal, ensure_ascii=False, indent=2), encoding='utf-8')
    checkpoint()
    for number, item in enumerate(runs, 1):
        print(f'Uploading {number}/{len(runs)}: {item["name"]}', flush=True)
        receipt = dict(name=item['name'], state='started', url=None)
        journal['runs'].append(receipt)
        checkpoint()
        try:
            run = swanlab.init(project=args.project,workspace=args.workspace,
                           experiment_name=item['name'],group=item['group'],
                           description='Historical public-data import; original timestamps and hashes are in config. Mock runs are not real LLM calls.',
                           config=item['config'],mode='online',on_online_error='raise',
                           public=False,logdir=str(ROOT/'swanlog'))
            for step in item['steps']:
                swanlab.log(step['metrics'],step=step['step'])
            url = getattr(run,'url',None)
            receipt['url'] = url if isinstance(url,str) else None
            swanlab.finish()
            receipt['state'] = 'completed'
            checkpoint()
        except Exception as exc:
            receipt['state'] = 'unknown_or_failed'
            receipt['error_type'] = type(exc).__name__
            journal['state'] = 'interrupted'
            checkpoint()
            raise RuntimeError('Upload interrupted. Check the cloud project and local receipts before retrying.') from None
    journal['state'] = 'completed'
    checkpoint()
    print(f'Uploaded {len(journal["runs"])} runs. Verify project access and obtain its HTTPS URL in the browser.')


if __name__ == '__main__':
    main()
