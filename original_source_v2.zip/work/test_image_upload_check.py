"""Check that container prediction uses uploaded bytes and rejects corruption."""
import base64
import hashlib
import tempfile
import unittest
from pathlib import Path
from e2e import uploaded_checkpoint


class UploadCheck(unittest.TestCase):
    def test_uploaded_bytes_and_corrupt_digest(self):
        content = b"selected artifact uploaded through official host protocol"
        digest = "sha256:" + hashlib.sha256(content).hexdigest()
        frames = [
            {"type": "upload_begin_request", "files": [
                {"path": "checkpoint.npz", "size_bytes": len(content), "sha256": digest}]},
            {"type": "upload_chunk_request", "upload_id": "0", "path": "checkpoint.npz",
             "offset": 0, "data_base64": base64.b64encode(content).decode()},
            {"type": "candidate_request", "upload_id": "0",
             "artifact": {"checkpoint_paths": ["checkpoint.npz"]}},
        ]
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "model"
            self.assertEqual(uploaded_checkpoint(frames, target), digest)
            self.assertEqual((target / "checkpoint.npz").read_bytes(), content)
            frames[0]["files"][0]["sha256"] = "sha256:corrupt"
            with self.assertRaisesRegex(ValueError, "digest mismatch"):
                uploaded_checkpoint(frames, Path(directory) / "corrupt")


if __name__ == "__main__":
    unittest.main()
