# -*- coding: utf-8 -*-
"""策略网格实验：在 A/B/C 上扫 (epochs, lr)，产出可写进说明书的对照数据。

每个组合都从官方父检查点续训，记录验证集指标、步数增量、墙钟时间，
最后按数据集输出"相对父检查点的提升"排名，并写 CSV/JSON 到 work/
"""
import csv
import json
import os
import subprocess
import sys
import time

PY = sys.executable
ROOT = os.environ.get("CONTEST_DATA_ROOT", str(__import__("pathlib").Path(__file__).resolve().parents[1]))
OUT = str(__import__("pathlib").Path(__file__).resolve().parent / "sweep_rerun")
KEYS = ["A", "B", "C"]
MAIN = {"A": "macro_f1", "B": "rmse", "C": "rmse"}
HIGHER_BETTER = {"A": True, "B": False, "C": False}

GRID = [(e, lr) for e in (1, 2, 4, 8) for lr in (0.001, 0.002, 0.003, 0.005)]


def run(key, epochs, lr):
    pkg = os.path.join(ROOT, key)
    tag = f"e{epochs}-lr{lr}"
    out = os.path.join(OUT, key, tag)
    cmd = [PY, "-m", "baselines.train", "--profile", key,
           "--train", "public/train.jsonl", "--validation", "public/validation.jsonl",
           "--from-baseline", "checkpoint.npz", "--epochs", str(epochs),
           "--learning-rate", str(lr), "--output", out, "--stage-id", tag]
    t0 = time.perf_counter()
    p = subprocess.run(cmd, cwd=pkg, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    wall = time.perf_counter() - t0
    if p.returncode != 0:
        return None, wall, (p.stderr or p.stdout)[-400:]
    lines = [l for l in p.stdout.splitlines() if l.startswith("{")]
    if not lines:
        return None, wall, "no report json"
    return json.loads(lines[-1]), wall, None


def main():
    os.makedirs(OUT, exist_ok=True)
    rows = []
    for key in KEYS:
        m = MAIN[key]
        print(f"\n===== 数据集 {key}（主指标 {m}，{'越大' if HIGHER_BETTER[key] else '越小'}越好）=====")
        print(f"{'epochs':>7}{'lr':>8}{'主指标前':>12}{'主指标后':>12}{'变化':>10}"
              f"{'步数':>8}{'耗时s':>9}")
        best = None
        for epochs, lr in GRID:
            rep, wall, err = run(key, epochs, lr)
            if rep is None:
                print(f"{epochs:>7}{lr:>8}  失败: {err}")
                continue
            vb, va = rep["validation_before"], rep["validation_after"]
            b, a = vb[m], va[m]
            d = a - b
            ok = d > 0 if HIGHER_BETTER[key] else d < 0
            rows.append({"dataset": key, "epochs": epochs, "lr": lr,
                         "before": b, "after": a, "delta": d, "improved": ok,
                         "steps_before": rep["initial_steps"], "steps_after": rep["final_steps"],
                         "wall_seconds": round(wall, 3),
                         "training_seconds": rep["training_seconds"],
                         "params": rep["parameter_count"]})
            print(f"{epochs:>7}{lr:>8}{b:>12.4f}{a:>12.4f}{d:>+10.4f}"
                  f"{rep['final_steps']:>8}{wall:>9.2f} {'✓' if ok else '✗'}")
            score = d if HIGHER_BETTER[key] else -d
            if best is None or score > best[0]:
                best = (score, epochs, lr, d)
        if best:
            print(f"  → 最优: epochs={best[1]} lr={best[2]} 变化={best[3]:+.4f}")

    csv_path = os.path.join(OUT, "sweep.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    json_path = os.path.join(OUT, "sweep.json")
    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=1)
    print(f"\n已写入 {csv_path}（{len(rows)} 行）")


if __name__ == "__main__":
    main()
