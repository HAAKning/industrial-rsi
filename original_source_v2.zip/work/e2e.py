# -*- coding: utf-8 -*-
"""用官方 SDK 的 host 替身跑一遍真实协议：train（start 帧→候选→finish）与 predict。

用法：python work\\e2e.py A
      python work\\e2e.py A B C
"""
import hashlib
import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import uuid
from pathlib import Path

PY = sys.executable
ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = Path(os.environ.get("CONTEST_DATA_ROOT", str(ROOT)))
SDK = ROOT / "sdk" / "contest-harness-sdk-1.0.4"
APP = ROOT / "submission" / "app"
sys.path.insert(0, str(SDK))

from tests.support import Host  # noqa: E402
from contest_harness.predict import normalize_output  # noqa: E402


class FrameReader:
    """Record the actual upload while the unmodified official Host handles RPC."""
    def __init__(self, stream):
        self.stream = stream
        self.frames = []

    def readline(self):
        line = self.stream.readline()
        if line:
            self.frames.append(json.loads(line))
        return line


def uploaded_checkpoint(frames, destination):
    candidates = [f for f in frames if f.get("type") == "candidate_request"]
    if len(candidates) != 1:
        raise ValueError("Expected exactly one submitted candidate")
    candidate = candidates[0]
    if candidate["artifact"]["checkpoint_paths"] != ["checkpoint.npz"]:
        raise ValueError("Unexpected checkpoint declaration")
    uploads = [f for f in frames if f.get("type") == "upload_begin_request"]
    upload_id = candidate["upload_id"]
    manifest = uploads[int(upload_id)]["files"]
    item = next(x for x in manifest if x["path"] == "checkpoint.npz")
    content = bytearray()
    for frame in frames:
        if (frame.get("type") == "upload_chunk_request"
                and frame.get("upload_id") == upload_id
                and frame.get("path") == "checkpoint.npz"):
            if frame["offset"] != len(content):
                raise ValueError("Checkpoint upload offset mismatch")
            content.extend(base64.b64decode(frame["data_base64"], validate=True))
    digest = "sha256:" + hashlib.sha256(content).hexdigest()
    if len(content) != item["size_bytes"] or digest != item["sha256"]:
        raise ValueError("Submitted checkpoint digest mismatch")
    destination.mkdir()
    (destination / "checkpoint.npz").write_bytes(content)
    return digest

PROMPT = "从官方基线与公开训练、验证数据出发，在授权预算内自主提出假设。"
PLAN = {
    "A": {"strategy": "push", "epochs": 4, "lr": 0.003, "why": "A 集历史平稳，加大步长仍有收益"},
    "B": {"strategy": "fine_tune", "epochs": 2, "lr": 0.005, "why": "B 集轮数多会过拟合，取小轮数大步长"},
    "C": {"strategy": "fine_tune", "epochs": 1, "lr": 0.001, "why": "C 集学习率敏感，先小步试探"},
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def start_frame(key, train_path, val_path, parent_path, digest):
    task = "classification" if key == "A" else "regression"
    metric = "macro_f1" if key == "A" else "rmse"
    direction = "higher" if key == "A" else "lower"
    parent = {
        "artifact_id": f"baseline-{key.lower()}",
        "artifact_sha256": digest,
        "artifact": {
            "checkpoint_paths": ["checkpoint.npz"],
            "code_paths": [],
            "predict_argv": ["python3", "/app/harness.py", "predict"],
        },
        "files": [{"path": "checkpoint.npz", "sha256": digest, "size_bytes": parent_path.stat().st_size}],
    }
    return {
        "protocol": "contest.harness.workspace.v2",
        "run_id": f"run-e2e-{key}",
        "dataset_key": key,
        "round_index": 1,
        "stage_id": "public-development",
        "prompt": PROMPT,
        "prompt_version": "industrial-workspace-flexible-v3",
        "rounds_per_dataset": 10,
        "parent_checkpoint_sha256": digest,
        "task_contract": {
            "dataset_key": key,
            "task": task,
            "metric": metric,
            "metric_direction": direction,
            "public_projection": {
                "train_path": str(train_path),
                "validation_path": str(val_path),
                "row_fields": ["id", "inputs", "answer"],
                "source_metadata": False,
            },
        },
        "model_name": "base:test-model",
        "parent_artifact": parent,
        "artifacts": [parent],
        "state_sha256": "",
        "state_path": None,
        "max_output_tokens": 512,
        "resource_limits": {"artifact_upload_protocol": "chunked-v1",
                            "artifact_bytes": 512 * 1024 * 1024, "state_bytes": 512 * 1024 * 1024,
                            "candidate_upload_bytes_per_round": 1024 * 1024 * 1024,
                            "state_upload_bytes_per_round": 512 * 1024 * 1024},
        "current_validation": {},
        "wall_seconds": 600,
    }


def run_train(key, tmp):
    data = DATA_ROOT / key
    train_path = data / "public" / "train.jsonl"
    val_path = data / "public" / "validation.jsonl"
    parent = data / "checkpoint.npz"
    digest = sha256_file(parent)
    prev = tmp / "previous"
    prev.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(parent, prev / "checkpoint.npz")
    state = tmp / "state"
    state.mkdir(exist_ok=True)
    ws = tmp / "ws"
    ws.mkdir(exist_ok=True)

    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(SDK), str(APP)])
    env["CONTEST_SUBMISSION"] = "contest_submission"
    env["CONTEST_WORK"] = str(tmp)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["WORKSPACE_DIR"] = str(ws)
    env["PARENT_CHECKPOINT"] = str(prev / "checkpoint.npz")
    env["STATE_DIR"] = str(state)

    docker = os.environ.get("E2E_TARGET", "local") == "docker"
    container_name = "contest-check-" + uuid.uuid4().hex[:12]
    proc = subprocess.Popen(
        [PY, str(SDK / "template" / "harness.py"), "train"],
        cwd=str(APP), env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
    ) if os.environ.get("E2E_TARGET", "local") == "local" else subprocess.Popen(
        # 直接测「提交上去的那个镜像」：/app 只读、/workspace 可写，和评测机一致
        ["docker", "run", "--rm", "--name", container_name,
         "-i", "--platform", "linux/amd64", "--network", "none", "--read-only",
         "--cpus", "2", "--memory", "4g", "--pids-limit", "128",
         "--tmpfs", "/tmp:rw,nosuid,size=256m",
         "-v", f"{data}:/data:ro",
         "-v", f"{prev}:/previous:ro",
         "-v", f"{ws}:/workspace",
         "-v", f"{state}:/state:ro",
         "-e", "CONTEST_WORK=/workspace",
         "-e", "STATE_DIR=/state",
         "-e", "PYTHONDONTWRITEBYTECODE=1",
         os.environ.get("E2E_IMAGE", "team/harness:v2"), "train"],        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
    )
    plan = PLAN[key]

    def stub_model(messages, options):
        return {
            "request_id": f"call-{key}",
            "id": "chatcmpl-e2e",
            "choices": [{"message": {"role": "assistant",
                                     "content": json.dumps(plan, ensure_ascii=False)}}],
        }

    frame_train = "/data/public/train.jsonl" if docker else train_path
    frame_val = "/data/public/validation.jsonl" if docker else val_path
    host = Host(start_frame(key, frame_train, frame_val, parent, digest), stub_model,
                history=[{"id": "round-0", "round_index": 0}])
    recorder = FrameReader(proc.stdout)
    proc.stdout = recorder
    stderr_chunks = []
    drain = threading.Thread(target=lambda: stderr_chunks.append(proc.stderr.read()), daemon=True)
    drain.start()
    thread = host.serve(proc)
    try:
        code = proc.wait(timeout=900)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=30)
        raise RuntimeError("Training exceeded 900 seconds")
    finally:
        if docker:
            subprocess.run(["docker", "rm", "-f", container_name],
                           capture_output=True, timeout=30, check=False)
        thread.join(timeout=10)
        drain.join(timeout=10)
    stderr = "".join(stderr_chunks)
    ok = (code == 0 and not thread.is_alive() and host.failure is None
          and host.record is not None and bool(host.record.get("model_call_ids")))
    print(f"[{'pass' if ok else 'FAIL'}] {key} exit={code}")
    if not ok:
        print("host.failure:", host.failure)
        print("stderr tail:", stderr[-2000:])
        return False
    rec = host.record
    print("   artifact:", rec.get("selected_artifact_id"),
          "| calls:", rec.get("model_call_ids"),
          "| hist:", rec.get("history_ids"))
    print("   config:", json.dumps(rec.get("configuration"), ensure_ascii=False)[:200])
    print("   reason:", (rec.get("reason") or "")[:160])
    # 预测：用提交上去的候选目录里的检查点
    model_dir = tmp / "model"
    selected_digest = uploaded_checkpoint(recorder.frames, model_dir)
    cand = model_dir / "checkpoint.npz"
    lines = []
    with open(val_path, encoding="utf-8") as fh:
        for i, line in enumerate(fh):
            if i >= 3:
                break
            row = json.loads(line)
            lines.append(json.dumps({"task": start_frame(key, train_path, val_path, parent, digest)["task_contract"]["task"],
                                     "inputs": row["inputs"]}, ensure_ascii=False))
    penv = env.copy()
    penv["CONTEST_ARTIFACT_PATH"] = str(cand)
    predict_cmd = [PY, str(SDK / "template" / "harness.py"), "predict"]
    if docker:
        predict_cmd = ["docker", "run", "--rm", "-i", "--platform", "linux/amd64",
                       "--network", "none", "--read-only", "--cpus", "2", "--memory", "4g",
                       "--tmpfs", "/tmp:rw,nosuid,size=256m", "--pids-limit", "128",
                       "-v", f"{model_dir}:/model:ro",
                       os.environ.get("E2E_IMAGE", "team/harness:v2"), "predict"]
    pout = subprocess.run(predict_cmd,
                          input="\n".join(lines) + "\n", env=penv, text=True,
                          encoding="utf-8", errors="replace", capture_output=True,
                          check=False, timeout=120)
    outs = [json.loads(x) for x in pout.stdout.splitlines() if x.strip()]
    for output in outs:
        normalize_output("classification" if key == "A" else "regression", output)
    good = pout.returncode == 0 and len(outs) == len(lines)
    report_dir = os.environ.get("E2E_REPORT_DIR")
    if report_dir:
        report_path = Path(report_dir)
        report_path.mkdir(parents=True, exist_ok=True)
        (report_path / f"{key}.json").write_text(json.dumps({
            "dataset": key, "passed": good, "target": "docker" if docker else "local",
            "image": os.environ.get("E2E_IMAGE") if docker else None,
            "model_access": "official_host_mock", "real_llm_call": False,
            "selected_checkpoint_sha256": selected_digest,
            "parent_checkpoint_sha256": digest, "record": rec,
            "prediction_count": len(outs), "predictions": outs,
            "training_stderr": stderr, "prediction_stderr": pout.stderr,
            "offline": docker, "read_only_root": docker,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"   predict {'ok' if good else 'FAIL'}: {pout.stdout.strip()[:220]}")
    if not good:
        print("   predict stderr:", pout.stderr[-800:])
    return good


def main(keys):
    results = {}
    for key in keys:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                results[key] = run_train(key, Path(tmp))
            except Exception as exc:
                print(f"[FAIL] {key}: {type(exc).__name__}: {exc}")
                results[key] = False
    print("\nsummary:", results)
    return 0 if all(results.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:] or ["A"]))
