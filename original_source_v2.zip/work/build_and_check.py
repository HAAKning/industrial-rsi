"""Build and verify the corrected image. Run manually outside the restricted session.

Uses cached official base images only. Does not install packages, use API keys,
upload to the competition, or consume evaluation attempts.
"""
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
IMAGE = "team/harness:v2"
REPORT = ROOT / "evidence" / "image_v2_verification.json"
LOG = ROOT / "evidence" / "image_v2_build.log"
DATA = Path(os.environ.get("CONTEST_DATA_ROOT", "D:/AI\u5b58\u50a8/contest"))


def run(args, *, capture=False, timeout=900, env=None):
    print("\n> " + subprocess.list2cmdline([str(x) for x in args]), flush=True)
    result = subprocess.run(args, cwd=ROOT, env=env, text=True, encoding="utf-8",
                            errors="replace", stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write("\n> " + subprocess.list2cmdline([str(x) for x in args]) + "\n")
        handle.write(result.stdout or "")
    if not capture or result.returncode:
        print(result.stdout or "", flush=True)
    if result.returncode:
        raise RuntimeError(f"Command failed, exit={result.returncode}; see {LOG.name}")
    return result.stdout


def main():
    REPORT.parent.mkdir(exist_ok=True)
    state = {"started_utc": datetime.now(timezone.utc).isoformat(), "status": "started",
             "image": IMAGE, "real_llm_call": False, "platform_attempts_used": 0}
    REPORT.write_text(json.dumps(state, indent=2), encoding="utf-8")
    try:
        run(["docker", "version", "--format", "{{.Server.Version}}"], timeout=30)
        for base in ("python:3.12-alpine", "alpine:3.22"):
            run(["docker", "image", "inspect", base], capture=True, timeout=30)
        for key in "ABC":
            for path in (DATA / key / "checkpoint.npz", DATA / key / "public" / "train.jsonl",
                         DATA / key / "public" / "validation.jsonl"):
                if not path.is_file():
                    raise FileNotFoundError(path)
        run([sys.executable, str(ROOT / "submission/local/test_policy_limits.py")], timeout=60)
        run(["docker", "build", "--pull=false", "--network=none", "--platform", "linux/amd64",
             "--provenance=false", "--sbom=false", "-t", IMAGE, str(ROOT / "submission")])
        desc_raw = run(["docker", "run", "--rm", "--network", "none", "--read-only",
                        "--tmpfs", "/tmp:rw,size=64m", IMAGE, "describe"], capture=True, timeout=60)
        desc = json.loads(desc_raw)
        if desc.get("protocol") != "contest.harness.workspace.v2":
            raise ValueError("Unexpected describe protocol")
        state["describe"] = desc
        env = os.environ.copy()
        env.update(E2E_TARGET="docker", E2E_IMAGE=IMAGE, CONTEST_DATA_ROOT=str(DATA),
                   E2E_REPORT_DIR=str(ROOT / "evidence/image_v2_checks"), PYTHONIOENCODING="utf-8")
        run([sys.executable, str(ROOT / "work/e2e.py"), "A", "B", "C"], env=env, timeout=3000)
        target = ROOT / "dist/harness_v2.tar"
        target.parent.mkdir(exist_ok=True)
        run(["docker", "save", "-o", str(target), IMAGE], timeout=300)
        run([sys.executable, str(ROOT / "submission/tools/verify_image.py"), str(target)], timeout=120)
        if target.stat().st_size > 50_000_000:
            raise ValueError("Image exceeds 50 MB direct-upload limit")
        with target.open("rb") as handle:
            digest = hashlib.file_digest(handle, "sha256").hexdigest()
        checks = {key: json.loads((ROOT / f"evidence/image_v2_checks/{key}.json").read_text(encoding="utf-8"))
                  for key in "ABC"}
        if not all(x["passed"] for x in checks.values()):
            raise RuntimeError("A dataset check failed")
        state.update(status="passed", completed_utc=datetime.now(timezone.utc).isoformat(),
                     tar=str(target), size_bytes=target.stat().st_size, sha256=digest,
                     dataset_checks=checks)
        print("\nPASS: corrected image built and A/B/C mock protocol + prediction checks passed.")
        print("This is an offline Mock check, not a real PyTRiO or platform evaluation.")
    except Exception as exc:
        state.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        print("\nFAILED:", state["error"])
        print("If cached base images are missing, do not download anything yet; report this result.")
    finally:
        REPORT.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if state["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
