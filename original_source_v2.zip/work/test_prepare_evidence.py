"""Offline checks only; these do not prove a successful cloud upload."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prepare_evidence_under_test', HERE / 'prepare_evidence.py')
uploader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(uploader)
SOURCE = uploader.ROOT


class FakeSwanLab(types.ModuleType):
    __version__ = 'test-fake'

    def __init__(self, fail_at=None):
        super().__init__('swanlab')
        self.inits = []
        self.logs = []
        self.finished = 0
        self.fail_at = fail_at
        self.login_options = None

    def login(self, **kwargs):
        self.login_options = kwargs

    def init(self, **kwargs):
        self.inits.append(kwargs)
        if len(self.inits) == self.fail_at:
            raise ConnectionError('simulated network interruption')
        assert kwargs['public'] is False
        assert kwargs['mode'] == 'online'
        assert kwargs['on_online_error'] == 'raise'
        return types.SimpleNamespace(url='https://example.invalid/test-run')

    def log(self, metrics, step):
        self.logs.append((dict(metrics), step))

    def finish(self):
        self.finished += 1


class EvidenceUploadTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        shutil.copytree(SOURCE / 'evidence/grid', self.root / 'evidence/grid')
        (self.root / 'work').mkdir()
        shutil.copyfile(SOURCE / 'work/selftest_log.txt', self.root / 'work/selftest_log.txt')
        self.root_patch = patch.object(uploader, 'ROOT', self.root)
        self.root_patch.start()

    def tearDown(self):
        self.root_patch.stop()
        self.tmp.cleanup()

    def invoke(self, fake, prompt=False):
        argv = ['prepare_evidence.py', '--online', '--project', 'industrial-rsi', '--workspace', 'HAAKning']
        if prompt:
            argv.append('--prompt-key')
        with patch.object(sys, 'argv', argv), patch.dict(sys.modules, {'swanlab': fake}), contextlib.redirect_stdout(io.StringIO()):
            uploader.main()

    def journal(self):
        return json.loads((self.root / 'evidence/swanlab_upload_receipts.json').read_text(encoding='utf-8'))

    def test_complete_known_history(self):
        runs = uploader.records()
        self.assertEqual(len(runs), 51)
        self.assertEqual(sum(len(r['config'].get('original_epoch_history', [])) for r in runs), 180)
        self.assertEqual(sum(len(r['steps']) for r in runs[48:]), 9)

    def test_success_preserves_private_destination_and_all_points(self):
        fake = FakeSwanLab()
        with patch.object(uploader.getpass, 'getpass', return_value='test-only-not-a-real-key'):
            self.invoke(fake, prompt=True)
        self.assertEqual(len(fake.inits), 51)
        self.assertEqual(len(fake.logs), 285)
        self.assertEqual(fake.finished, 51)
        self.assertFalse(fake.login_options['save'])
        record = self.journal()
        self.assertEqual(record['state'], 'completed')
        self.assertTrue(all(r['state'] == 'completed' for r in record['runs']))
        self.assertNotIn('test-only-not-a-real-key', json.dumps(record))
        self.assertTrue(all(r['workspace'] == 'HAAKning' for r in fake.inits))

    def test_partial_failure_is_journaled_and_not_retried(self):
        fake = FakeSwanLab(fail_at=2)
        with self.assertRaisesRegex(RuntimeError, 'interrupted'):
            self.invoke(fake)
        record = self.journal()
        self.assertEqual(record['state'], 'interrupted')
        self.assertEqual([r['state'] for r in record['runs']], ['completed', 'unknown_or_failed'])
        with self.assertRaisesRegex(RuntimeError, 'receipts already exist'):
            self.invoke(fake)
        self.assertEqual(len(fake.inits), 2)


if __name__ == '__main__':
    unittest.main()
