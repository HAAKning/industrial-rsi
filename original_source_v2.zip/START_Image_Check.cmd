@echo off
setlocal
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo Build and verify corrected contest image using cached base images.
echo No package installation, API key, platform upload or evaluation attempt.
python -u work\build_and_check.py
echo.
echo Show ChatGPT this result. Do not rerun until checked.
pause
