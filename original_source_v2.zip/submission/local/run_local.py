# -*- coding: utf-8 -*-
"""离线跑 A/B/C 各 3 轮，验证"读历史—做实验—依据结果决策"的闭环。

用法: python run_local.py [轮数]
输出: 每轮指标、采纳/回滚、耗时，以及写出的实验记录。
"""
import json
import os
import shutil
import tempfile
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE.parent / "app"
sys.path.insert(0, str(APP))
sys.path.insert(0, str(HERE))

import contest_submission  # noqa: E402
from mock_rnd import MockRnd  # noqa: E402

ROOT = Path(os.environ.get("CONTEST_DATA_ROOT", str(Path(__file__).resolve().parents[2])))
WORK = Path(tempfile.mkdtemp(prefix="contest-selftest-"))


def sha_of(path):
    import hashlib
    return "sha256:" + hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    rounds = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    WORK.mkdir(parents=True)

    for key in ("A", "B", "C"):
        pkg = ROOT / key
        parent = pkg / "checkpoint.npz"
        history = []
        print(f"\n===== 数据集 {key} =====")
        for r in range(1, rounds + 1):
            ws = WORK / key / f"round{r}"
            ws.mkdir(parents=True, exist_ok=True)
            os.environ["WORKSPACE_DIR"] = str(ws)
            rnd = MockRnd(key, r, parent,
                          pkg / "public" / "train.jsonl",
                          pkg / "public" / "validation.jsonl",
                          history=history, state_dir=ws / "state")
            if r > 1:
                prev = WORK / key / f"round{r-1}" / f"round-{r-1:02d}" / "state"
                rnd._state_seed = prev
                os.environ["STATE_DIR"] = str(prev)
            else:
                os.environ.pop("STATE_DIR", None)
            out = contest_submission.train(rnd)
            assert rnd.finished is not None, "finish() 没被调用"
            assert rnd.finished["model_call_ids"], "model_call_ids 为空会被平台拒绝"
            arts = rnd.submissions[0]
            ckpt = Path(arts["dir"]) / "checkpoint.npz"
            plan = rnd.receipts[0]["plan"]
            print(f"  第{r}轮 策略={plan.get('strategy'):<16} epochs={plan.get('epochs')} "
                  f"lr={plan.get('lr')} | 指标={out['metrics']} 采纳={out['improved']}")
            # 平台会选中我们提交的候选；这里用它当下一轮的父检查点
            parent = ckpt
            history.append({"id": f"h{key}{r}", "dataset_key": key, "round_index": r,
                            "measurements": out["metrics"]})
        # 检查实验记录
        log = WORK / key / f"round{rounds}" / f"round-{rounds:02d}" / "state" / "experiments.jsonl"
        assert log.exists(), f"实验记录缺失: {log}"
        print(f"  实验记录行数={len(log.read_text(encoding='utf-8').strip().splitlines())}"
              f"（模拟平台把上一轮 state 带进下一轮后累积）")
    print("\n全部通过：3 个数据集各跑完 %d 轮，均完成决策→训练→采纳/回滚→提交→finish。" % rounds)


if __name__ == "__main__":
    main()
