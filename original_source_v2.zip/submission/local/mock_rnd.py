# -*- coding: utf-8 -*-
"""离线假平台：按 SDK 文档里 rnd 的接口形状实现一份 mock，用来在没有
PyTRiO 额度、没有评测平台的情况下，把 train 闭环完整跑通。

它模拟"大模型决策"：读诊断 JSON 后按漂移等级返回一个策略 JSON，
其中有 1/4 概率返回越界策略，用来验证 guard 会不会把它拦下来。
"""
import json
import os
import sys
from pathlib import Path

# 复用选手侧的策略表，保证"假平台"和真实 guard 用同一套取值
_APP = Path(__file__).resolve().parent.parent / "app"
if str(_APP) not in sys.path:
    sys.path.insert(0, str(_APP))
try:
    import policy                                  # noqa: E402
except Exception:                                  # noqa: BLE001
    policy = None


class _Parent:
    def __init__(self, ckpt_path, sha):
        self._ckpt = str(ckpt_path)
        self.checkpoint_sha256 = sha

    def path(self, rel):
        return self._ckpt


class _Data:
    def __init__(self, train_path, val_path):
        self._train = str(train_path)
        self._val = str(val_path)

    def training_rows(self):
        with open(self._train, encoding="utf-8") as fh:
            return [json.loads(line) for line in fh if line.strip()]

    def validation_rows(self):
        with open(self._val, encoding="utf-8") as fh:
            return [json.loads(line) for line in fh if line.strip()]


class _Receipt:
    def __init__(self, text, call_id):
        self.text = text
        self.response = {"choices": [{"message": {"content": text}}]}
        self.call_id = call_id


class MockRnd:
    """只实现 train(rnd) 用到的那些字段/方法。"""

    def __init__(self, key, round_index, parent_ckpt, train_path, val_path,
                 history=None, state_dir=None, seed_plan=None):
        self.dataset_key = key
        self.round_index = round_index
        self.task = {"task": "classification" if key == "A" else "regression", "metric": "macro_f1" if key == "A" else "rmse",
                     "public_projection": {"train": str(train_path), "validation": str(val_path)}}
        self.parent = _Parent(parent_ckpt, f"sha256:{key}-parent-r{round_index}")
        self.data = _Data(train_path, val_path)
        self.model_name = "mock-qwen3.8-27b"
        self.max_output_tokens = 512
        self.limits = {}
        self.call_ids = []
        self._history = list(history or [])
        self._state_dir = Path(state_dir) if state_dir else None
        self._n = 0
        self.receipts = []
        self.submissions = []
        self.finished = None
        self.seed_plan = seed_plan

    # --- 平台接口 -------------------------------------------------------
    def model(self, messages, max_tokens=None, temperature=0):
        self._n += 1
        ctx = {}
        try:
            ctx = json.loads(messages[-1]["content"])
        except Exception:                              # noqa: BLE001
            pass
        level = ctx.get("drift_level", "low")
        key = ctx.get("dataset_key") or self.dataset_key
        if self.seed_plan:
            plan = dict(self.seed_plan)
        else:
            # 大模型"提议"：先照默认策略，再按历史调整；偶尔故意越界检验 guard
            plan = dict(policy.default_plan(level, key))
            prev = ctx.get("previous_attempts") or []
            if prev and prev[-1].get("improved") is False:
                plan = dict(policy.default_plan("high" if level != "low" else "medium", key))
                plan["why"] = "上一轮没有改善，换一档更积极的步子重新试探"
            if self._n % 4 == 0:      # 故意越界，检验 guard
                plan = {"strategy": "rewrite_everything", "epochs": 99, "lr": 1.0,
                        "why": "（故意的越界策略，用于验证 guard）"}
        text = json.dumps(plan, ensure_ascii=False)
        cid = f"mock-call-{self.dataset_key}-{self.round_index}-{self._n}"
        self.call_ids.append(cid)
        self.receipts.append({"call_id": cid, "ctx": ctx, "plan": plan})
        return _Receipt(text, cid)

    def history(self):
        return self._history

    def state_workspace(self, path):
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        # 模拟平台把上一轮 /state 的内容带进来
        seed = getattr(self, "_state_seed", None)
        if seed and Path(seed).is_dir():
            for item in Path(seed).iterdir():
                if item.is_file():
                    (p / item.name).write_bytes(item.read_bytes())
        return p

    def save_state(self, state):
        self.saved_state = str(state)

    def submit_candidate(self, candidate_dir, **kwargs):
        art = f"artifact-{self.dataset_key}-r{self.round_index}"
        self.submissions.append({"artifact_id": art, "dir": str(candidate_dir), **kwargs})
        return {"artifact_id": art, "validation": kwargs.get("configuration")}

    def restore_artifact(self, artifact_id, path):
        Path(path).mkdir(parents=True, exist_ok=True)
        return str(path)

    def finish(self, **kwargs):
        self.finished = kwargs
        return {"ok": True}

    def transport(self):
        raise NotImplementedError("mock 不提供 transport")
