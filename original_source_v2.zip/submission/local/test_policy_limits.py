"""Regression checks for malformed model replies and dataset-specific limits."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))
import policy


def main():
    checked = 0
    proposals = [None, {}, {'strategy': 'invalid'},
                 {'strategy': 'aggressive', 'epochs': 100, 'lr': 1},
                 {'strategy': 'fine_tune', 'epochs': True, 'lr': True},
                 {'strategy': 'push', 'epochs': 4, 'lr': float('nan')},
                 {'strategy': 'push', 'epochs': 4, 'lr': float('inf')}]
    for dataset in ('A', 'B', 'C'):
        for level in ('low', 'medium', 'high'):
            for proposal in proposals:
                plan = policy.guard(proposal, level, dataset)
                limits = policy.limits_for(plan['strategy'], dataset)
                assert plan['strategy'] in policy.allowed_actions(level)
                assert type(plan['epochs']) is int and plan['epochs'] in limits['epochs']
                assert plan['lr'] in limits['lr'], (dataset, level, proposal, plan)
                assert plan['guarded'] is True
                checked += 1
            for name in policy.allowed_actions(level):
                limits = policy.limits_for(name, dataset)
                for epochs in limits['epochs']:
                    for lr in limits['lr']:
                        proposal = dict(strategy=name, epochs=epochs, lr=lr, why='test')
                        plan = policy.guard(proposal, level, dataset)
                        assert plan['epochs'] == epochs and plan['lr'] == lr
                        assert plan['guarded'] is False
                        checked += 1
    print(f'PASS: {checked} invalid/boundary/valid decisions respect dataset limits')


if __name__ == '__main__':
    main()
