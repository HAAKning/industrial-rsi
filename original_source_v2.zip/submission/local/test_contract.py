# -*- coding: utf-8 -*-
"""协议契约自测：确认 train() 不污染 stdout、predict() 输出格式合规。

平台按行读 stdout 的 JSONL，任何一行多余输出都会破坏协议，
所以这里把 stdout 重定向到内存再跑一轮真训练，断言一字未写。

用法:
    python test_contract.py            # A 与 C
    python test_contract.py A B C      # 指定数据集
"""
import contextlib
import io
import json
import os
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "app"))

import mock_rnd                                        # noqa: E402
import contest_submission as cs                        # noqa: E402

DATA = Path(os.environ.get("CONTEST_DATA_ROOT", str(Path(__file__).resolve().parents[2])))


def check_stdout_clean(key):
    """跑一轮 train，断言 stdout 一字节都没写。"""
    with tempfile.TemporaryDirectory() as tmp:
        env_backup = {k: os.environ.get(k) for k in ("WORKSPACE_DIR", "STATE_DIR", "PARENT_CHECKPOINT")}
        os.environ["WORKSPACE_DIR"] = str(Path(tmp) / "workspace")
        os.environ["STATE_DIR"] = str(Path(tmp) / "state")
        os.environ.pop("PARENT_CHECKPOINT", None)
        rnd = mock_rnd.MockRnd(
            key, 1,
            DATA / key / "checkpoint.npz",
            DATA / key / "public" / "train.jsonl",
            DATA / key / "public" / "validation.jsonl",
            state_dir=Path(tmp) / "state",
        )
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                cs.train(rnd)
        finally:
            for k, v in env_backup.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
        leaked = buf.getvalue()
        assert leaked == "", f"{key}: stdout 被写入了 {len(leaked)} 字节: {leaked[:200]!r}"
        assert rnd.finished, f"{key}: 没有调用 finish"
        assert rnd.call_ids, f"{key}: 没有调用大模型"
        return len(rnd.finished["model_call_ids"])


def check_predict(key, task):
    """预测输出必须是平台能直接吃下的结构。"""
    model_dir = Path(tempfile.mkdtemp()) / "model"
    model_dir.mkdir(parents=True)
    src = DATA / key / "checkpoint.npz"
    (model_dir / "checkpoint.npz").write_bytes(src.read_bytes())

    cfg = json.loads((DATA / key / "baselines" / "configs" / f"{key}.json").read_text(encoding="utf-8"))
    sample_file = DATA / key / "public" / "validation.jsonl"
    samples = []
    for line in sample_file.read_text(encoding="utf-8").splitlines()[:3]:
        rec = json.loads(line)
        samples.append({"task": task, "inputs": rec["inputs"]})

    for s in samples:
        out = cs.predict(s, str(model_dir))
        if task == "classification":
            assert isinstance(out, list) and out, f"{key}: 分类输出不是非空 list"
            labels = cfg.get("classes", [])
            for item in out:
                assert set(item) >= {"label", "score"}, f"{key}: 分类项缺字段 {item}"
                assert item["label"] in labels, f"{key}: 出现未知类别 {item['label']}"
                assert isinstance(item["score"], float) and 0.0 <= item["score"] <= 1.0
            assert abs(sum(i["score"] for i in out) - 1.0) < 1e-3, f"{key}: 各项分数之和不为 1"
        else:
            # predict() 返回的是协议内层载荷（外层 {"outputs": ...} 由 SDK 模板负责包）
            value = out["value"] if isinstance(out, dict) and "value" in out else out
            assert isinstance(value, float), f"{key}: 回归输出不是浮点数: {out!r}"
            assert value >= 0, f"{key}: 回归值为负: {value}"

    # 平台模板可能只传 sample（产物路径走环境变量），这种调用方式也要能接住
    os.environ["CONTEST_ARTIFACT_PATH"] = str(model_dir / "checkpoint.npz")
    try:
        out0 = cs.predict(samples[0])
    finally:
        os.environ.pop("CONTEST_ARTIFACT_PATH", None)
    assert out0 is not None, f"{key}: 单参数调用 predict() 失败"
    return len(samples)


def main():
    keys = sys.argv[1:] or ["A", "C"]
    task_of = {"A": "classification", "B": "regression", "C": "regression"}
    ok = True
    for key in keys:
        try:
            n_calls = check_stdout_clean(key)
            n_pred = check_predict(key, task_of[key])
            print(f"[pass] {key}: stdout 干净，model_call_ids={n_calls}，预测 {n_pred} 条合规")
        except AssertionError as exc:
            ok = False
            print(f"[fail] {exc}")
    if not ok:
        raise SystemExit(1)
    print("契约自测通过")


if __name__ == "__main__":
    main()
