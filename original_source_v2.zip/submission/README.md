# Contest Harness v2

Full project documentation and reproducibility steps are in ../README.md at the source archive root.

Runtime: Linux/amd64, Alpine 3.22, Python 3.12, NumPy 1.26.4, official contest-harness-sdk 1.0.4.
Entrypoint: python3 /app/harness.py
CONTEST_SUBMISSION=contest_submission (module name, never a file path).

The corrected team/harness:v2 image passed offline A/B/C train-protocol and prediction checks. The Host uses preset replies; this is not a real PyTRiO call or platform evaluation.

Public historical experiments: https://swanlab.cn/@HAAKning/industrial-rsi

See NOTICE.md for third-party components. Do not store API keys in this directory or the Docker image.
