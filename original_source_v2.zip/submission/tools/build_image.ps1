﻿# 一键构建并导出评测镜像（Windows PowerShell）
#
# 用法（在 submission 目录下）:
#   .\tools\build_image.ps1                                  # 默认找桌面上的 SDK 包
#   .\tools\build_image.ps1 -Sdk "D:\xx\contest-harness-sdk-1.0.4.tar.gz" -Tag "team/harness:v1"
#
# 做四件事：检查环境 → 把 SDK 包放进构建上下文 → docker build → docker save + 体积报告
# 产物: ..\dist\harness_v1.tar

param(
    [string]$Sdk  = "$env:USERPROFILE\Desktop\contest-harness-sdk-1.0.4.tar.gz",
    [string]$Tag  = "team/harness:v1",
    [string]$Out  = ""
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)   # submission/
if (-not $Out) { $Out = Join-Path (Split-Path -Parent $here) "dist\harness_v1.tar" }

function Fail($msg) { Write-Host "[FAIL] $msg" -ForegroundColor Red; exit 1 }

# 1) 环境检查
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Fail "找不到 docker。先装 Docker Desktop，并确认 `docker run --rm hello-world` 能通过。"
}
$ver = (docker version --format '{{.Server.Version}}' 2>$null)
if (-not $ver) { Fail "docker 客户端在，但连不上引擎。请先启动 Docker Desktop，等小鲸鱼变绿。" }
Write-Host "[ok] docker engine $ver"

# 2) 构建上下文检查
if (-not (Test-Path $Sdk)) {
    Fail "找不到 SDK 包: $Sdk`n请把它下载到桌面，或用 -Sdk 指定路径。"
}
$sdkSize = [math]::Round((Get-Item $Sdk).Length / 1MB, 1)
Write-Host "[ok] SDK: $Sdk ($sdkSize MB)"

$ctx = Join-Path $here "contest-harness-sdk-1.0.4.tar.gz"
if (-not (Test-Path $ctx)) { Copy-Item $Sdk $ctx }
Write-Host "[ok] 构建上下文就绪: $here"

# 3) 构建（linux/amd64 必须是显式的，Windows 默认平台可能不对）
Push-Location $here
try {
    docker build --platform linux/amd64 -t $Tag .
    if ($LASTEXITCODE -ne 0) { Fail "docker build 失败，看上面的报错。" }

    # 4) 冒烟：容器里 describe 必须输出合法 JSON
    $desc = docker run --rm --platform linux/amd64 $Tag describe
    if ($LASTEXITCODE -ne 0) { Fail "容器内 describe 失败。" }
    Write-Host "[smoke] $desc"
    if ($desc -notmatch '"protocol"') { Fail "describe 输出里没有 protocol 字段。" }

    # 5) 导出
    $dir = Split-Path -Parent $Out
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    if (Test-Path $Out) { Remove-Item $Out -Force }
    docker save $Tag -o $Out
    if ($LASTEXITCODE -ne 0) { Fail "docker save 失败。" }

    $tarMB = [math]::Round((Get-Item $Out).Length / 1MB, 1)
    Write-Host "[done] $Out ($tarMB MB)" -ForegroundColor Green

    # 6) 落一份元数据，给 dist\镜像下载链接.docx 自动填体积与校验值
    $sizeHuman = "$tarMB MB"
    if ($tarMB -ge 1024) { $sizeHuman = "{0:N2} GB" -f ($tarMB / 1024) }
    $hash = (Get-FileHash $Out -Algorithm SHA256).Hash.ToLower()
    $stamp = Get-Date
    $info = [ordered]@{
        tag        = $Tag
        file       = (Split-Path -Leaf $Out)
        bytes      = (Get-Item $Out).Length
        size_human = $sizeHuman
        sha256     = $hash
        built_at   = $stamp.ToString("yyyy-MM-dd HH:mm")
        platform   = "linux/amd64"
    }
    $infoPath = Join-Path (Split-Path -Parent $Out) "image_info.json"
    $json = $info | ConvertTo-Json
    [System.IO.File]::WriteAllText($infoPath, $json, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host ("[meta] " + $infoPath + "  sha256=" + $hash.Substring(0, 16) + "...") -ForegroundColor Cyan
    Write-Host "提示：重新生成 dist\镜像下载链接.docx 可自动带上体积与 SHA256" -ForegroundColor Cyan
    Write-Host "      python work\build_linkdoc.py" -ForegroundColor Cyan

    if ($tarMB -gt 50) {
        Write-Host "[warn] 超过 50 MB，平台要求改为网盘链接 + doc/docx 说明。" -ForegroundColor Yellow
    }
    Write-Host "下一步：python tools\verify_image.py `"$Out`"" -ForegroundColor Cyan
}
finally {
    Pop-Location
}
