# -*- coding: utf-8 -*-
"""把 contest_harness SDK 自带的入口模板装成 /app/harness.py。

SDK 文档要求："把 template/harness.py 放到 /app/harness.py"。本脚本在构建镜像时
执行，这样镜像里就有平台期望的固定入口，而选手代码只保留 contest_submission.py。
"""
import filecmp
import shutil
import sys
from pathlib import Path

TARGET = Path("/app/harness.py")


def find_template():
    import contest_harness
    pkg = Path(contest_harness.__file__).resolve().parent
    for cand in [pkg / "template" / "harness.py", pkg.parent / "template" / "harness.py",
                 pkg / "harness.py"]:
        if cand.is_file():
            return cand
    for cand in pkg.parent.rglob("harness.py"):
        if cand.is_file():
            return cand
    return None


def main():
    template = find_template()
    if template is None:
        print("找不到 contest_harness 的入口模板，请检查 SDK 安装是否完整", file=sys.stderr)
        return 2
    if TARGET.exists() and filecmp.cmp(template, TARGET, shallow=False):
        print(f"入口已就位: {TARGET}")
        return 0
    shutil.copyfile(template, TARGET)
    print(f"已安装入口模板: {template} -> {TARGET}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
