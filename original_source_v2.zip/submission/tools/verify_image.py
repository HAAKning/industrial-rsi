# -*- coding: utf-8 -*-
"""校验 `docker save` 出来的镜像 tar 结构，不需要 docker 环境。

平台要的是「单个 Linux/amd64 的未压缩 tar」。上传前先在这里过一遍，
比拿一次试运行去试错便宜得多。

用法:
    python tools/verify_image.py ..\dist\harness_v1.tar

检查项
  1. tar 可读、不是 gzip 压缩、顶层有 manifest.json
  2. manifest.json 里恰好一个镜像，RepoTags 非空，Layers 数量与 tar 内一致
  3. 配置 JSON 存在、architecture=amd64、os=linux
  4. Entrypoint/Cmd 指向 /app/harness.py
  5. 体积报告（>50MB 时提示平台要求改网盘链接）
"""
import json
import sys
import tarfile
from pathlib import Path

LIMIT_MB = 50


def check(path: Path) -> int:
    if not path.is_file():
        print(f"[FAIL] 文件不存在: {path}")
        return 1
    size_mb = path.stat().st_size / 1024 / 1024
    print(f"[info] {path.name}: {size_mb:.1f} MB")
    if path.read_bytes()[:2] == b"\x1f\x8b":
        print("[FAIL] 这是 gzip 压缩包；平台要的是未压缩的 tar（别用 tar.gz）")
        return 1

    problems = []
    with tarfile.open(path, "r:") as tar:
        names = tar.getnames()
        if "manifest.json" not in names:
            print("[FAIL] 顶层没有 manifest.json，不像 docker save 的产物")
            return 1

        manifest = json.loads(tar.extractfile("manifest.json").read().decode("utf-8"))
        if len(manifest) != 1:
            problems.append(f"manifest 里有 {len(manifest)} 个镜像，平台只要一个")
        entry = manifest[0]
        layers = entry.get("Layers", [])
        tags = entry.get("RepoTags") or []
        print(f"[ok] 镜像条目 1 个，标签 {tags}，层数 {len(layers)}")
        if not tags:
            problems.append("RepoTags 为空（docker save 时没带 -t）")
        missing = [l for l in layers if l not in names]
        if missing:
            problems.append(f"{len(missing)} 个层在 tar 里找不到，例如 {missing[0]}")

        cfg_name = entry.get("Config", "")
        if cfg_name not in names:
            problems.append("manifest 指向的配置 JSON 不存在")
        else:
            cfg = json.loads(tar.extractfile(cfg_name).read().decode("utf-8"))
            arch = (cfg.get("architecture"), cfg.get("os"))
            print(f"[ok] 架构 {arch[0]}/{arch[1]}")
            if arch != ("amd64", "linux"):
                problems.append(f"架构是 {arch[0]}/{arch[1]}，平台要 linux/amd64")
            c = cfg.get("config", {})
            entrypoint = c.get("Entrypoint") or []
            cmd = c.get("Cmd") or []
            print(f"[ok] Entrypoint={entrypoint}  Cmd={cmd}")
            if not any("/app/harness.py" in str(x) for x in list(entrypoint) + list(cmd)):
                problems.append("Entrypoint/Cmd 里没有 /app/harness.py")
            env = c.get("Env") or []
            if not any(e.startswith("CONTEST_SUBMISSION=") for e in env):
                problems.append("缺少 CONTEST_SUBMISSION 环境变量")
            else:
                print("[ok] CONTEST_SUBMISSION 已设置")

    if size_mb > LIMIT_MB:
        print(f"[warn] {size_mb:.1f} MB 超过 {LIMIT_MB} MB：平台要求上传网盘链接（doc/docx 说明），"
              "不能直接传这个 tar")
    if problems:
        for p in problems:
            print(f"[FAIL] {p}")
        return 1
    print("[pass] 镜像 tar 结构正常，可以上传")
    return 0


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    return check(Path(sys.argv[1]))


if __name__ == "__main__":
    raise SystemExit(main())
